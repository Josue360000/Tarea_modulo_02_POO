package com.mycompany.gestiondeempleados;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class empleado {
private String nombre;
private int edad;
private double salario;

public empleado(String nombre, int edad, double salario) {
this.nombre = nombre;
setedad(edad);
setsalario(salario);
}

public String getnombre() {
return nombre;
}

public void setnombre(String nombre) {
this.nombre = nombre;
}

public int getedad() {
return edad;
}

public void setedad(int edad) {
if (edad >= 0) {
this.edad = edad;
} else {
System.out.println("\nNo puedes ingresar un numero negativo para la edad, se asignara con valor 0");
this.edad = 0;
}
}

public double getsalario() {
return salario;
}

public void setsalario(double salario) {
if (salario >= 0) {
this.salario = salario;
} else {
System.out.println("\nNo puedes ingresar un numero negativo para el salario, se asignara con valor 0");
this.salario = 0.0;
}
}

public void mostrarempleado() {
System.out.println("\n-------------------------------------");
System.out.println("Nombre: " + nombre);
System.out.println("Edad: " + edad);
System.out.println("Salario: Lps." + salario);
System.out.println("\n-------------------------------------");
}
}

class gestordeempleados {
private List<empleado> listadeempleados;

public gestordeempleados() {
listadeempleados = new ArrayList<>();
}

public void agregarempleado(empleado empleado) {
listadeempleados.add(empleado);
System.out.println("\nEl empleado: " + empleado.getnombre() + " fue ingresado correctamente");
}

public void mostrarlistadeempleados() {
if (listadeempleados.isEmpty()) {
System.out.println("\nNo hay empleados por los momentos");
} else {
for (empleado empleado : listadeempleados) {
empleado.mostrarempleado();
}
}
}
}

public class Gestiondeempleados {
public static void main(String[] args) {
gestordeempleados gestor = new gestordeempleados();
Scanner scanner = new Scanner(System.in);
char opcion = 'a';

while (opcion != 'c') {
System.out.println("\n-------------------------------------");
System.out.println("\nPrograma de gestion de empleados");
System.out.println("a. Agregar empleado");
System.out.println("b. Mostrar empleados");
System.out.println("c. Salir del programa");
System.out.print("Seleccione una opcion: ");
opcion = scanner.next().charAt(0);
scanner.nextLine();

switch (opcion) {
case 'a':
System.out.print("\nIngrese el nombre del empleado: ");
String nombre = scanner.nextLine();

System.out.print("Ingrese la edad del empleado: ");
int edad = scanner.nextInt();

System.out.print("Ingrese el salario del empleado: ");
double salario = scanner.nextDouble();

empleado nuevoempleado = new empleado(nombre, edad, salario);
gestor.agregarempleado(nuevoempleado);
break;

case 'b':
gestor.mostrarlistadeempleados();
break;

case 'c':
System.out.println("\nHa salido del programa");
scanner.close();
opcion = 'c';
break;

default:
System.out.println("\nOperacion no valida");
}
}
}
}




